<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="h3 mb-4 text-gray-800">
                <?php echo $judul; ?>
            </h1>
            <div class="row">
                <div class="col-md-12"><a href="<?= base_url('index.php/') ?>Mahasiswa/tambah" class="btn btn-info mb-2">Tambah Mahasiswa</a>
                    <div class="col-md-12">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Nama</td>
                                    <td>Nim</td>
                                    <td>Email</td>
                                    <td>Aksi</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Hisyam Fadhillah</td>
                                    <td>2255301073</td>
                                    <td>hisyam22ti@mahasiswa.pcr.ac.id</td>
                                    <td>
                                        <a href="" class="btn btn-danger">Hapus</a>
                                        <a href="" class="btn btn-warning">Edit</a>
                                        <a href="<?= base_url('index.php/') ?>Mahasiswa/detail" class="btn btn-info">Detail</a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>